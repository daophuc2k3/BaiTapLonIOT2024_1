package com.android.iot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeAndoridApplication {

    public static void main(String[] args) {
        SpringApplication.run(BeAndoridApplication.class, args);
    }

}
