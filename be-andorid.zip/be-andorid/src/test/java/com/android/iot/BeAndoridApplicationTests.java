package com.android.iot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeAndoridApplicationTests {

    @Test
    void contextLoads() {
    }

}
